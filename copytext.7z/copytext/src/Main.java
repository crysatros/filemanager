public class Main {

    public static void main(String[] args) {
        String origFile = "D:\\testo.txt";
        String copyFile = "D:\\testc.txt";
        try {
            FileManager fileManager = new FileManager();
            double[] copyStat = new double[2];
            copyStat = fileManager.copy(origFile, copyFile);
            System.out.println("Скорость копирования: " + copyStat[0] + "Мб/с\n Время: " + copyStat[1] + " seconds");
        }catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}