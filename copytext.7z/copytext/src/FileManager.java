import java.io.*;

public class FileManager  {
    final int size4Mb = 4*1024*1024;

    public double[] copy(String orig, String copy) throws IOException{
        double[] stat = new double[2];
        try{
            FileInputStream is = new FileInputStream(orig);
            FileOutputStream os = new FileOutputStream(copy);
            byte[] buf = new byte[size4Mb];
            int len;
            long CopyTime = System.currentTimeMillis();
            long totalSize = 0;
            long endCopy = System.currentTimeMillis();
            long copyTime = endCopy - CopyTime;

            while((len = is.read(buf))>0){
                os.write(buf);
                totalSize += len;
            }
            stat[1] = ((double) copyTime) / 1000;
            try {
                stat[0] = ((double)totalSize / 1000) / copyTime;
            }
            catch(ArithmeticException e){
                stat[0] = 0;
            }
            finally{
                is.close();
                os.close();
            }
        }catch (FileNotFoundException e){
        }
        catch (IOException e){
        }
        return stat;
    }
}